#!/usr/bin/python
# coding=utf-8
#
# hello.py
#
# Pierwszy program w Pythonie.
# W pierwszej linii mamy ścieżkę dostępu do interpretera.
# W drugiej linii informacja o kodowaniu znaków w pliku.
# Dzięki temu można w pliku stosować polskie znaki w napisach.
# Po znaku '#' mamy komentarz do końca linii.

print ( "Hello, world!" )   # działa dla Pythona 2 i 3