#include "graph.h"

int main() {
    Graf* g = new Graf();
    g->readFromFile("/Users/oleksandrsuliz/Desktop/uni/sem4/cpp_uj_2/ex_3/tests/graph_1.txt");
}